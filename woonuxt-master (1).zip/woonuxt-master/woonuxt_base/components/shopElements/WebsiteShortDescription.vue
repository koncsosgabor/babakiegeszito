<template>
  <p class="mt-4 text-sm text-gray-700 xl:max-w-md">
    WooNuxt is unmatched when it comes to performance and scalability. Reap the benefits of having a online store that out performs all of your competitors. You can edit components
    to display your own information just like the one you're reading now.
  </p>
</template>
